import dataStructures.Array;
import dataStructures.ArrayClass;
import dataStructures.Iterator;

public class GossiperPersonClass extends PersonClass {
	private String type;
	private Array<Gossip> gossips;
	private int posGossip;

	public GossiperPersonClass(String name) {
		super(name);
		this.gossips = new ArrayClass<>();
		this.type = "gossiper";
		this.posGossip = 0;
	}

	public String getType() {
		return type;
	}

	@Override
	public Iterator<Gossip> getGossipsToShare() {
		if (gossips.size() <= 3) {
			return gossips.iterator();
		}

		Array<Gossip> gossipsToShare = new ArrayClass<>(3);
		for (int i = 0; i < 3; i++) {
			gossipsToShare.insertAt(gossips.get(posGossip), i);
			posGossip++;
			if (posGossip == gossips.size()) {
				posGossip = 0;
			}
		}

		return gossipsToShare.iterator();
	}

	

	@Override
	public void listenGossip(Gossip next) {
		gossips.insertLast(next);
	}

	public int getCapacity() {
        return 0;
    }

	@Override
	public Array<Gossip> getGossips() {
		return gossips;
	}

	@Override
	public int getNumOfGossips() {
		return gossips.size();
	}
	
    @Override
    public boolean hasGossip(Gossip sharedGossip) {
        return gossips.searchForward(sharedGossip);
    }
	
    @Override
    public boolean hasSharedAGossip(Person person) {
        boolean check = false;
        for (int i = 0; i < gossips.size(); i++) {
            if (gossips.get(i).getShares() > 0) {
                check = true;
                break;
            }
        }

		return check;
	}

	@Override
	public Iterator<Gossip> getGossipsList() {
		Array<Gossip> list = new ArrayClass<Gossip>(gossips.size());
		for (int i = 0; i < gossips.size(); i++) {
			list.insertAt(gossips.get((posGossip + i) % gossips.size()), i);
		}

		return list.iterator();
	}
}